package util;

public class Constants {
	public static final String JDBC_DRIVER="com.mysql.jdbc.Driver";  
	public static final String DB_URL="jdbc:mysql://localhost:3306/classdiscuz";
	public static final String DBUSER = "root";
	public static final String DBPWD = "";
	public final static String SQL = "sql.properties";
}
