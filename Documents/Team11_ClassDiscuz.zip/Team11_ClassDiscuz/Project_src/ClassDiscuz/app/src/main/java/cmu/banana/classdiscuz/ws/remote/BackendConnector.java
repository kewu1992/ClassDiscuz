package cmu.banana.classdiscuz.ws.remote;

import android.util.Base64;

import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;

import cmu.banana.classdiscuz.entities.Course;
import cmu.banana.classdiscuz.entities.User;
import cmu.banana.classdiscuz.exception.SignUpException;

/*
 * Connector to communicate with the backend server, using GET and POST request.
 */
public class BackendConnector {

    private static final String BACKEND = "http://128.237.160.77:8080/ClassDiscuzBackend";

    public static ArrayList<User> getMembersByCourse(int courseId){
        User[] response = null;
        try {
            URL url = new URL(BACKEND+"/usersincourse");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "courseId="+courseId;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return null;
            }
            response = new Gson().fromJson(result, User[].class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<User> result = new ArrayList<User>();
        result.addAll(Arrays.asList(response));

        for (User user : result){
            /* transform image, decode Base64 */
            if (user.getAvatar() != null){
                String temp = new String(user.getAvatar()).replace(' ', '+');
                user.setAvatar(Base64.decode(temp.getBytes(), Base64.DEFAULT));
            }
        }
        return result;
    }

    public static ArrayList<Course> getCourses(int userID){
        Course[] response = null;
        try {

            URL url = new URL(BACKEND+"/registered");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "studentId="+userID;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return null;
            }

            response = new Gson().fromJson(result, Course[].class);


        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<Course> result = new ArrayList<Course>();
        result.addAll(Arrays.asList(response));
        return result;
    }

    public static User getMemberByID(int userID){
        User response = null;
        try {
            URL url = new URL(BACKEND+"/id");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "studentId="+userID;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();

            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return null;
            }

            response = new Gson().fromJson(result, User.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        /* transform image, decode Base64 */
        if (response.getAvatar() != null){
            String temp = new String(response.getAvatar()).replace(' ', '+');
            response.setAvatar(Base64.decode(temp.getBytes(), Base64.DEFAULT));
        }

        return response;
    }

    public static ArrayList<Course> getAllCourse() {
        Course[] response = null;
        try {
            URL url = new URL(BACKEND+"/allcourses");
            URLConnection connection = url.openConnection();
//            connection.setRequestProperty("Accept-Charset", charset);
            InputStream in = connection.getInputStream();

            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();

            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return null;
            }

            response = new Gson().fromJson(result, Course[].class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<Course> result = new ArrayList<Course>();
        result.addAll(Arrays.asList(response));
        return result;
    }

    public static int regOrDropCourse(int userId, int courseId) {
        try {

            URL url = new URL(BACKEND+"/regordrop?studentId="+userId +"&courseId="+courseId);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
//            String params = "studentId="+userId +"&courseId="+courseId;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            //out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();

            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return -1;
            }

            if (result.equals("{\"result\":\"00\"}"))
                return 0;
            if (result.equals("{\"result\":\"01\"}"))
                return 1;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return -1;
    }

    public static User signUp(String email,String password, String name) throws SignUpException{
        User response = null;
        try {
            URL url = new URL(BACKEND+"/signup");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "email="+email+"&password="+password+"&name="+name;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();

            //exception
            if (result.equals("{\"result\":\"1\"}")) {
                throw new SignUpException(1, "Database Exception.");
            }
            if (result.equals("{\"result\":\"2\"}")) {
                throw new SignUpException(2, "Database Exception.");
            }
            if (result.equals("{\"result\":\"3\"}")) {
                throw new SignUpException(3, "The email already exits.");
            }

            response = new Gson().fromJson(result, User.class);
        }catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    public static User logIn(String email, String password) {
        User response = null;
        try {
            URL url = new URL(BACKEND+"/login");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "email="+email+"&password="+password;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")
                    || result.equals("{\"result\":\"3\"}")) {
                return null;
            }

            response = new Gson().fromJson(result, User.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    public static int updateProfile(int id, String name, String college, String major, byte[] image) {

        try {
            URL url = new URL(BACKEND+"/editprofile");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "studentId="+id+"&name="+name+"&college="+
                    college+"&major="+major;
            if (image != null) {
                params += "&avatar="+new String(Base64.encode(image, Base64.DEFAULT));
            }
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();

            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return -1;
            }
            return 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static int updateFocus(int studentId, int focus) {

        try {
            URL url = new URL(BACKEND+"/updatefocus");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "studentId="+studentId+"&focus="+focus;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();

            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return -1;
            }
            return 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static String getGeolocation(String address) {
        if (address == null || address.equals("null"))
            return null;

        String location = null;
        try {
            URL url = new URL(BACKEND+"/geolocation");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "address="+address;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();
            String result = sb.toString();
            if (result.equals("null")) {
                return null;
            }
            location = result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return location;
    }


    public static Course getCourseByID(int courseId){
        Course response = null;
        try {
            URL url = new URL(BACKEND+"/c_id");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String params = "courseId="+courseId;

            con.setDoOutput(true);
            con.setDoInput(true);
            con.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(con.getOutputStream());

            out.write(params.getBytes());
            out.flush();
            out.close();

            InputStream in = new BufferedInputStream(con.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = r.readLine()) != null) {
                sb.append(str);
            }
            in.close();

            String result = sb.toString();
            if (result.equals("{\"result\":\"1\"}") || result.equals("{\"result\":\"2\"}")) {
                return null;
            }

            response = new Gson().fromJson(result, Course.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }
}
